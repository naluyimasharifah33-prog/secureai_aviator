# SecureAI Aviator Intelligence prototype

This free-first prototype records completed multipliers manually and calculates descriptive historical statistics.

## Files
- `index.html`: responsive dashboard, local history, average, median, maximum and historical threshold frequencies.
- `manifest.json`: installable web app metadata.
- `sw.js`: basic offline cache.

## Test
Open `index.html` in a browser. Add completed sample multipliers or use the sample data button. Data is saved locally in that browser/device.

## Publish later
1. Create a new GitHub repository named `secureai-aviator` (separate from Connect Beyond Borders and any other project).
2. Upload all three files to the repository root.
3. In Cloudflare, open Workers & Pages > Create > Pages > Connect to Git.
4. Select `secureai-aviator`; use no build command and `/` as output directory if requested.
5. Deploy. Open the HTTPS site on Android Chrome and choose Install app or Add to Home screen from the browser menu.

## Limits and safety
This is a prototype, not a production prediction service. It does not predict the next crash point or guarantee wins. Historical frequencies are descriptive and do not prove future probabilities, particularly if rounds are independent. Data is stored only in local browser storage; there is no account system, cloud sync, actual AI, admin dashboard, payment processing or subscription system yet. Do not automate bets, access private bookmaker systems, or collect betting credentials. Confirm data sources are authorised. Before commercial launch, add privacy/security review, terms, support, backups, account security and verified payment integration.
